############  database definition  ###################
# configuration
DATABASE = './db/test.db'
DEBUG = True
SECRET_KEY = 'awodgaiwgoawidasdoifaqnfow284524u0t2ef'
USERNAME = 'admin'
PASSWORD = 'test1234'

DB_SQL = 'schema.sql'
DB_SQL_UPDATE = 'update.sql'