flask기반의 backend

0. VDB/notice 에다가 finetuned-kr-sbert-notice 모델 폴더 통째로 옮기기
1. 파이썬 버전 - 3.11 이상
2. 파이썬 가상환경 설치
3. pip install -r requirements.txt 실행
4. python3 app.py 실행
5. 만약 특정 모듈이 설치가 안되어 있다면 pip install로 직접 설치 (app.py 실행해가면서 설치 안되어있다는 모듈 하나씩 다 설치해야함)