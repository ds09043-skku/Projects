def get_notice():
    return 0